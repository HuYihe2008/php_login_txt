<?php

$a = "asfasbcasdfnaosdfaabc";

$b = "abc";

if( strstr($a, $b) ){

  echo "$a中包含字符串“abc”。\n";

}else{

  echo "$a中不包含字符串“abc”。\n";

}

?>